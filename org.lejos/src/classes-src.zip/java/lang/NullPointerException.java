package java.lang;

public class NullPointerException extends RuntimeException
{
}
