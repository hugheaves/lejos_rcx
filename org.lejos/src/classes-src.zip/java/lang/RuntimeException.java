package java.lang;

public class RuntimeException extends Exception
{
}
