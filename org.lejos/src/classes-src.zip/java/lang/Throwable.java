package java.lang;

/**
 * All exceptions and errors extend this class.
 */
public class Throwable
{
  public Throwable() {
  }
    
  public String getMessage()
  {
    return "";
  }
}
