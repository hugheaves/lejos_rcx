package java.lang;

public class ClassNotFoundException extends Exception
{
}
